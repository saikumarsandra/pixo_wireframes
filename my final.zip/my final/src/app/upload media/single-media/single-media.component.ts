import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';

import { HttpClient } from '@angular/common/http';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';

@Component({
  selector: 'app-single-media',
  templateUrl: './single-media.component.html',
  styleUrls: ['./single-media.component.css']
})
export class SingleMediaComponent implements OnInit {

  form: FormGroup;
  file: File;

  constructor(private fb: FormBuilder, private http: HttpClient, private authService: AuthenticationService, private router: Router, private userService: UserRegistrationService) { }

  ngOnInit() {
  }
}
   