import { Injectable } from '@angular/core';
import{ HttpClient} from '@angular/common/http';
import { UserRegistrationDetails} from 'src/app/model/User-registration';
import { Observable } from 'rxjs';


const API_URL = "http://localhost:8765/user-service/users";
const REGISTER_URL = "http://localhost:8765/user-service/register";

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {

  username: String="";
  id: number;
  email: String="";
  constructor(public http : HttpClient) { 

  }

/*
  getAllUsers() {
    return this.http.get(API_URL);
  }
  getOneuser(id:number){
    // GET http verb
    return this.http.get(API_URL + "/" + id);

  }

 
  addNewUser(details:UserRegistrationDetails){
    return this.http.post(API_URL,details);
  }
   updateuser(details:UserRegistrationDetails, id:number){
    return this.http.put(API_URL+"/"+id,details);
  }

  deleteProduct(id:number){
    // DELETE http verb
    return this.http.delete(API_URL + "/" + id);

  }*/





  getAllUsers(){
    // send request to server to get all products
    // this.http.post(API_URL);
    // will send a request to API_URL with http verb GET(retrieval)
    // method will wait for data to receive
    // return data back to component
    return this.http.get(API_URL);
  }

  // method to send new object(product) to server
  addNewUser(User : UserRegistrationDetails){
    // POST http verb
    return this.http.post(REGISTER_URL,User );
  }

  // methid to get single record of given id
  getOneUser(id:number):any{
    // GET http verb
    return this.http.get(API_URL + "/" + id);

  }

  // method to send updated object(product) to server
  updateUser(id:number, user : UserRegistrationDetails){
    // PUT http verb
    return this.http.put(API_URL + "/" + id, user);
  }

  // method to delete single record of given id
 // deleteUser(id:number){
    // DELETE http verb
  //  return this.http.delete(API_URL + "/" + id);

  }
/*//follow
follow(uid: number, fid: number): Observable<Object> {
  return this.http.get(API_URL+ '/' + uid + '/' + fid);
}

following(uid: number): Observable<any> {
  return this.http.get(API_URL+ uid);
}

followers(uid: number): Observable<any> {
  return this.http.get(API_URL + uid);
}

unfollow(uid:number, fid:number): Observable<any> {
  return this.http.delete(API_URL + uid + '/' + fid);
}

block(id: number) { 
  return this.http.put(API_URL+this.id+'/'+id,{ responseType: 'text' })
}

getBlockedUsers() :Observable<any>{
  return this.http.get(API_URL+this.id); 
}

unblock(id: number) {
  return this.http.put(API_URL+this.id+'/'+id,{responseType: 'text'})
}*/














  

