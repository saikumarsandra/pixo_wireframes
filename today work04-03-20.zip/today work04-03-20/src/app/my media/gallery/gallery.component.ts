import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  constructor(private sanitizer:DomSanitizer ,private userService: UserRegistrationService, private authService: AuthenticationService, private router: Router) { }


  ngOnInit() {
    


  }
}
