import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-my-media-details',
  templateUrl: './my-media-details.component.html',
  styleUrls: ['./my-media-details.component.css']
})
export class MyMediaDetailsComponent implements OnInit {

  constructor(public auth:AuthenticationService) { }

  ngOnInit() {
  }

}
