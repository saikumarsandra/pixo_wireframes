package com.cts.training.actionservice.service;

import java.util.List;

import com.cts.training.actionservice.entity.Action;

public interface IActionService {

	List<Action> findAllActions();
	Action findActionById(Integer id);
	boolean addAction(Action Action);
	boolean updateAction(Action Action);
	boolean deleteAction(Integer id);
}
