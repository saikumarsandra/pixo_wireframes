package com.pixogram.media.plumbing;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.web.client.RestTemplate;

import feign.Request;

@EnableFeignClients("com.pixogram.media.plumbing.feignproxy")
//enable/register as eureka client
@EnableEurekaClient

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	

	@Bean
	Request.Options requestOptions(ConfigurableEnvironment env){
		int ribbonReadTimeout =env.getProperty("ribbon.ReadTimeout", int.class,6000);
		int ribbonConnectionTimeout =env.getProperty("ribbon.ReadTimeout", int.class,6000);
		
		
		return new Request.Options(ribbonConnectionTimeout,ribbonReadTimeout);
	}
	
	
	
}
