package com.pixogram.media.plumbing.feignproxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import com.pixogram.media.plumbing.model.MediaDataModel;
@FeignClient(name = "api-gateway") // for passing all request through API Gateway
// configure the Ribbon to load balance
@RibbonClient(name = "media-service") // will activate load balancing on 

public interface MediaServiceProxy {

	
	
		@PostMapping(value="/media-service/media",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
		public boolean save (MultipartFile file);
		
		@PostMapping(value="/media-service/mediadata")
		public boolean saveData(@RequestBody MediaDataModel media);
	}

