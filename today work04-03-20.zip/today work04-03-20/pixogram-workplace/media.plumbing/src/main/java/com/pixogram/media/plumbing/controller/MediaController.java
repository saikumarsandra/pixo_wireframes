package com.pixogram.media.plumbing.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.pixogram.media.plumbing.feignproxy.MediaServiceProxy;
import com.pixogram.media.plumbing.model.MediaDataModel;



@RestController
public class MediaController {
	
	@Autowired
	private MediaServiceProxy mediaServiceProxy;
	
	Logger logger =  LoggerFactory.getLogger(this.getClass());
 
	
	private final String MediaUrl= "http;//localhost:9100/media-service/media";
	
	@PostMapping("/media")
	public void post (@RequestParam("file") MultipartFile file,
			@RequestParam("url") String url, 
			@RequestParam("title") String title,
			@RequestParam("description") String description,
			@RequestParam("tags") String tags,
			@RequestParam("userid") String userid,
			@RequestParam("type") String type
			) {
		
				MediaDataModel model = new MediaDataModel(Integer.parseInt(userid),url,title,description,tags,type);
					
			this.mediaServiceProxy.saveData(model);
			this.mediaServiceProxy.save(file);
	}
	
	
	
	
		
}
