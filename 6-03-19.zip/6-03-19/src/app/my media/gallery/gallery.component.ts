import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Media } from 'src/app/model/media.model';
import { MediauploadserviceService } from 'src/app/services/mediauploadservice.service';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
  
medialist: Array <Media>;

  constructor(private sanitizer:DomSanitizer ,private userService: UserRegistrationService, private authService: AuthenticationService, private router: Router,public ms:MediauploadserviceService) {
    this.ms.getAllMedia().subscribe((responce:any)=>{this.medialist=responce;console.log(responce)});
  
   }


  ngOnInit() {
    


  }
}
