package com.cts.training.bootapphibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootappHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootappHibernateApplication.class, args);
	}

}
