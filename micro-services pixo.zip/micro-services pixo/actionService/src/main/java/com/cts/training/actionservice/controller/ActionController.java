package com.cts.training.actionservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.actionservice.entity.Action;
import com.cts.training.actionservice.repository.ActionRepository;


@RestController
public class ActionController {

	// dependency
	@Autowired
	private ActionRepository actionRepository;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/action/{actionId}")
	public ResponseEntity<Action> actionDetail(@PathVariable Integer actionId){
		Optional<Action> record =  this.actionRepository.findById(actionId);
	Action action = new Action();
		if(record.isPresent())
			action = record.get();
		ResponseEntity<Action> response = new ResponseEntity<Action>(action, HttpStatus.OK);
		return response;
	}
}












