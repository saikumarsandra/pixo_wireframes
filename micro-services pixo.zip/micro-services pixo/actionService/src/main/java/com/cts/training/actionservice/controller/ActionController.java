package com.cts.training.actionservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.actionservice.entity.Action;
import com.cts.training.actionservice.repository.ActionRepository;
import com.cts.training.actionservice.service.IActionService;


@RestController
public class ActionController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private IActionService actionService;

	
	
	
	
	@GetMapping("/actions") // GET HTTP VERB
	public ResponseEntity<List<Action>> exposeAll() {
		
		List<Action> actions = this.actionService.findAllActions();
		ResponseEntity<List<Action>> response = 
								new ResponseEntity<List<Action>>(actions, HttpStatus.OK);
		
		
		return response;
	}
	
	
	
	
	
	
	
	// REST method that will recieve a movie Id and return details of that movie
	@GetMapping("/actions/{actionId}") // GET HTTP VERB
	public ResponseEntity<Action> getById(@PathVariable Integer actionId) {
		
		Action action = this.actionService.findActionById(actionId);
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	
	
	@PostMapping("/actions") // POST HTTP VERB
	public ResponseEntity<Action> save(@RequestBody Action action) {
		this.actionService.addAction(action);
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	
	
	@PutMapping("/actions/{actionId}")
	
		public ResponseEntity<Action> saveUpdate(@PathVariable Integer actionId,@RequestBody Action action) {
		
		Action a = new Action (actionId,action.getMediaId(),action.getUserId(),action.getStatus(),action.getCreatedOn());

		if(!this.actionService.updateAction(a))
			throw new RuntimeException("could not update");
			
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(a, HttpStatus.OK);

		return response;
	}
	
	
	
	
	
	@DeleteMapping("/actions/{actionId}")
	public ResponseEntity<Action> delete(@PathVariable Integer actionId) {
		
		Action action = this.actionService.findActionById(actionId);
		this.actionService.deleteAction(actionId);
		
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	
	
}












