package com.cts.training.Blockservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.Blockservice.entity.BlockedUser;

import com.cts.training.Blockservice.repository.BlockedUserRepository;


@RestController
public class BlockedUserController {

	// dependency
	@Autowired
	private BlockedUserRepository blockeduserRepository;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/blockedusers/{blockeduserId}")
	public ResponseEntity<BlockedUser> blockDetail(@PathVariable Integer blockeduserId){
		Optional<BlockedUser> record =  this.blockeduserRepository.findById(blockeduserId);
	BlockedUser block = new BlockedUser();
		if(record.isPresent())
			block = record.get();
		ResponseEntity<BlockedUser> response = new ResponseEntity<BlockedUser>(block, HttpStatus.OK);
		return response;
	}
}












