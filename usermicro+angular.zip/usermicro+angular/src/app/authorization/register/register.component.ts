import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';
import { UserRegistrationDetails } from 'src/app/model/User-registration';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  enabled:boolean;
  constructor( formBuilder: FormBuilder, public route : Router, public details:UserRegistrationService) {  
    
  /*  
    console.log("in form  builder of reg") ;
    this.myFormGroup=formBuilder.group({
    "username" : new FormControl(""),
    "email" : new FormControl(""),
    "password" : new FormControl(""),
    "repassword" : new FormControl(""),
   
  });*/
  
  }
  
  ngOnInit() { 
 
  }

  preview(file : HTMLInputElement){
    
  }
  register(txtName:HTMLInputElement, txtPass:HTMLInputElement,txtEmail:HTMLInputElement):void{
    
    let user= new UserRegistrationDetails(txtName.value,txtPass.value,txtEmail.value);

    // need to send it to server using product Data Service
    this.details.addNewUser(user).subscribe(
      (response) => {
        console.log(response);
        // navigate to product-list
        
        
        this.route.navigate(['/login']);
      });


    }

}
