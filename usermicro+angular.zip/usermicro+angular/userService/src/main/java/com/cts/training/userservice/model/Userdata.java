package com.cts.training.userservice.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Userdata {
	
	
	
	private Integer id;
	private String username;
	private String password;
	private String repassword;
	private String email;
	private String enable;

	
	

}
