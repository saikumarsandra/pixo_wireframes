package com.cts.training.userservice.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.training.userservice.entity.Roles;



@Repository
@Transactional
public class RolesRepoImp implements RolesRepository {
	
	@PersistenceContext
	private EntityManager em;
	
		
	@Override
	public void save(Roles role) {
		// TODO Auto-generated method stub
		this.em.merge(role);
	}

}
