package com.cts.training.userservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Usermodel {
		
private String username;
private String password;
private String repassword;
private String email;
private String enable;

}
